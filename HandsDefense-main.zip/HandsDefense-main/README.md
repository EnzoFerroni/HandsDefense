# Projeto Jogos Digitais
### HandsDefense

Enzo Ferroni - 10417100 - 10417100@mackenzista.com.br

Leonardo Rodrigues - 10418105 - 10418105@mackenzista.com.br

Mateo Zanette - 10417980 - 10417980@mackenzista.com.br

Pedro Andrade - 10408394 - 10408394@mackeznista.com.br

Rafael Neves - 10418316 - 10418316@mackenzista.com.br

### Links

https://postcron.com/image-splitter/en/